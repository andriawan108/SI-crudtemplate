<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>WebMag HTML Template</title>

		<!-- Google font -->
		<link href="<?php echo base_url();?>assets/https://fonts.googleapis.com/css?family=Nunito+Sans:700%7CNunito:300,600" rel="stylesheet"> 

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="<?php echo base_url();?>assets/https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="<?php echo base_url();?>assets/https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>

		<!-- Header -->
		<header id="header">
			<!-- Nav -->
			<div id="nav">
				<!-- Main Nav -->
				<div id="nav-fixed">
					<div class="container">
						<!-- logo -->
						<div class="nav-logo">
							<a href="dashboard" class="logo"><img src="<?php echo base_url();?>assets/./img/logo.png" alt=""></a>
						</div>
						<!-- /logo -->

						<!-- nav -->
						<ul class="nav-menu nav navbar-nav">
							<li><a href="">CRUD</a></li>
							<li class="cat-1"><a href="category.html">Web Design</a></li>
							<li class="cat-2"><a href="category.html">JavaScript</a></li>
							<li class="cat-3"><a href="category.html">Css</a></li>
							<li class="cat-4"><a href="category.html">Jquery</a></li>
						</ul>
						<!-- /nav -->

						<!-- search & aside toggle -->
						<div class="nav-btns">
							<button class="aside-btn"><i class="fa fa-bars"></i></button>
							<button class="search-btn"><i class="fa fa-search"></i></button>
							<div class="search-form">
								<input class="search-input" type="text" name="search" placeholder="Enter Your Search ...">
								<button class="search-close"><i class="fa fa-times"></i></button>
							</div>
						</div>
						<!-- /search & aside toggle -->
					</div>
				</div>
				<!-- /Main Nav -->
<br>
<br>
<h2>Data Kendaraan</h2>
<br>
	<a href="<?php echo base_url('index.php/crud/input'); ?>">Input Data</a>
	<br>
	<br>
	<table border="1">
		<tr>
			<th>No.</th>
			<th>Merek Kendaraan</th>
			<th>Nomor Polisi</th>
			<th colspan="2">Opsi</th>
		</tr>
		<?php 

			$no = 1;
			foreach ($query->result() as $baris) {
				echo "<tr>";
				echo "<td>".$no."</td>";
				echo "<td>".$baris->merek_kendaraan."</td>";
				echo "<td>".$baris->nopol."</td>";
				echo "<td><a href=".base_url('index.php/crud/edit/').$baris->id.">Edit</a></td>";
				echo "<td><a href=".base_url('index.php/crud/hapus/').$baris->id.">Hapus</a></td>";
				echo "</tr>";
			$no++; } 


		?>
	</table> 


		</footer>
		<!-- /Footer -->

		<!-- jQuery Plugins -->
		<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url();?>assets/js/main.js"></script>

	</body>
</html>
