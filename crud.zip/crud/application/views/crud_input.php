<!DOCTYPE html>
<html>
<body>

<form action="<?php echo base_url('index.php/crud/simpan'); ?>" method="POST">

	<h3>Input Data Kendaraan</h3>

	Merek Kendaraan :<br>
	<input type="text" name="merek_kendaraan">

	<br>
	<br>
	Nomor Polisi<br>
	<input type="text" name="nopol">

	<br><br>

	<input type="submit" value="Simpan">

</form> 
</body>
</html>