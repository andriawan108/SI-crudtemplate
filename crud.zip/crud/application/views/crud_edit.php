<!DOCTYPE html>
<html>
<body>

<form action="<?php echo base_url('index.php/crud/update'); ?>" method="POST">

<?php foreach ($query->result() as $baris) { ?>

	<h3>Edit Data Kendaraan</h3>

	<input type="hidden" name="id" value="<?php echo $baris->id; ?>">


	Merek Kendaraan :<br>
	<input type="text" name="merek_kendaraan" value="<?php echo $baris->merek_kendaraan; ?>">

	<br>
	<br>
	Nomor Polisi<br>
	<input type="text" name="nopol" value="<?php echo $baris->nopol; ?>">

	<br><br>

	<input type="submit" value="Update">
<?php } ?>
</form> 
</body>
</html>